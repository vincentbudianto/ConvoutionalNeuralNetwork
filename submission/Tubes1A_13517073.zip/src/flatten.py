import numpy as np

class FlatteningLayer:
    def flatten(self, featuremap):
        return(featuremap.flatten())